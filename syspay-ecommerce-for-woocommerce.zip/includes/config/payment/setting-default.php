<?php
return [
    [
        'title' => '尚未啟用精誠金融金流',
        'desc'  => '請前往<a href="' . admin_url( 'admin.php?page=wc-settings&tab=woosyspay_setting&section=syspay_main' ) . '">設定</a>',
        'id'    => 'empty_options',
        'type'  => 'title',
    ],
];