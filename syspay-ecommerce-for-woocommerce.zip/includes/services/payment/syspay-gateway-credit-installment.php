<?php

class Woosyspay_Gateway_Credit_Installment extends Woosyspay_Gateway_Base
{
    protected $payment_type;
    protected $min_amount;
    protected $number_of_periods;

    public function __construct()
    {
        $this->id                   = 'Woosyspay_Gateway_Credit_Installment';
        $this->payment_type         = 'Credit';
        $this->icon                 = plugins_url('images/icon.png', dirname(dirname(__FILE__)));
        $this->has_fields           = true;
        $this->method_title         = __('SYSPay Credit Installment', 'syspay-ecommerce-for-woocommerce');
        $this->method_description   = '使用精誠金融信用卡(分期)付款';

        $this->title                = $this->get_option('title');
        $this->description          = $this->get_option('description');
        $this->min_amount           = (int) $this->get_option('min_amount', 0);
        $this->number_of_periods    = $this->get_option('number_of_periods', []);

        $this->form_fields          = include WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/config/payment/settings-gateway-credit-installment.php' ;
        $this->init_settings();

        parent::__construct();

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function process_admin_options()
    {
        parent::process_admin_options();
    }

    public function is_available()
    {
        if ('yes' == $this->enabled && WC()->cart) {
            if (empty($this->number_of_periods)) {
                return false;
            }
            $total = $this->get_order_total();
            if ($total > 0) {
                if ($this->min_amount > 0 && $total < $this->min_amount) {
                    return false;
                }
            }
        }

        return parent::is_available();
    }

    // public function payment_fields()
    // {
    //     parent::payment_fields();
        // $total = $this->get_order_total();

        // echo '<p>' . _x('Number of periods', 'Checkout info', 'syspay-ecommerce-for-woocommerce');
        // echo '<select name="syspay_number_of_periods">';

        // foreach ($this->number_of_periods as $number_of_periods) {
            
        //     echo '<option value="' . esc_attr($number_of_periods) . '">' . wp_kses_post($number_of_periods) . '</option>';
        // }
        // echo '</select>';
    // }

    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);
        $order->add_order_note(__('Pay via SYSPay Credit(installment)', 'syspay-ecommerce-for-woocommerce'));

        // if (isset($_POST['syspay_number_of_periods'])) {
        //     $order->update_meta_data('_syspay_payment_number_of_periods', (int) $_POST['syspay_number_of_periods']);
        // }
        $order->save();

        wc_maybe_reduce_stock_levels($order_id);
        wc_release_stock_for_order($order);

        return [
            'result'   => 'success',
            'redirect' => $order->get_checkout_payment_url(true),
        ];
    }
}
