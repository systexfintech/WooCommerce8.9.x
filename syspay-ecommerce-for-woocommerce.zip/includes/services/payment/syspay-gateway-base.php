<?php

use Syspay\Sdk\Exceptions\RtnException;
use Syspay\Sdk\Factories\Factory;
use Helpers\Payment\Woosyspay_Payment_Helper;

class Woosyspay_Gateway_Base extends WC_Payment_Gateway {
    protected $paymentHelper;

    public function __construct() {
        // 載入共用
        $this->paymentHelper  = new Woosyspay_Payment_Helper;

        if ($this->enabled) {
            add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
        }

        // 感謝頁
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));

        
    }

    public function receipt_page($order_id) {
        if ($order = wc_get_order($order_id)) {
            syspay_log('前往付款', 'A00001', $order_id);

            

                $api_payment_info  = $this->paymentHelper->get_syspay_payment_api_info('AioCheckOut');
                $merchant_trade_no = $this->paymentHelper->get_merchant_trade_no($order->get_id(), get_option('woosyspay_payment_order_prefix'));

                // 精誠金融訂單顯示商品名稱判斷
                if ('yes' === get_option('woosyspay_enabled_payment_disp_item_name', 'yes')) {

                    // 取出訂單品項
                    $item_name = $this->paymentHelper->get_item_name($order);
                } else {
                    $item_name = '網路商品一批';
                }

                $return_url      = WC()->api_request_url('woosyspay_payment_callback', true);
                $client_back_url = $this->get_return_url($order);

                // 紀錄訂單其他資訊
                $order->update_meta_data('_woosyspay_payment_order_prefix', get_option('woosyspay_payment_order_prefix')); // 前綴
                $order->update_meta_data('_woosyspay_payment_merchant_trade_no', $merchant_trade_no); //MerchantTradeNo
                $order->update_meta_data('_woosyspay_query_trade_tag', 0);

                // 防止 hook 重複執行導致訂單歷程重複寫入
                if (!get_transient('woosyspay_receipt_page_executed_' . $order_id)) {
                    $order->add_order_note(sprintf(__('Syspay Payment Merchant Trade No %s', 'syspay-ecommerce-for-woocommerce'), $merchant_trade_no));
                    set_transient('woosyspay_receipt_page_executed_' . $order_id, true, 3600);
                }
                else delete_transient('woosyspay_receipt_page_executed_' . $order_id);
                
                $order->save();

                // 紀錄訂單付款資訊進 DB
                $this->paymentHelper->insert_syspay_orders_payment_status($order_id, $order->get_payment_method(), $merchant_trade_no);

                // 組合AIO參數
                try {
                    $factory = new Factory([
                        'hashKey' => $api_payment_info['hashKey'],
                        'hashIv'  => $api_payment_info['hashIv'],
                    ]);

                    $autoSubmitFormService = $factory->create('AutoSubmitFormWithCmvService');

                    $input = [
                        'MerchantID'        => $api_payment_info['merchant_id'],
                        'MerchantTradeNo'   => $merchant_trade_no,
                        'MerchantTradeDate' => date_i18n('Y/m/d H:i:s'),
                        'TotalAmount'       => (int) ceil($order->get_total()),
                        'TradeDesc'         => $item_name,
                        'ItemName'          => $item_name,
                        'ChoosePayment'     => $this->payment_type,
                        'ReturnURL'         => $return_url,
                        'ClientBackURL'     => $client_back_url,
                        'PaymentInfoURL'    => $return_url,
                        'NeedExtraPaidInfo' => 'Y',
                    ];

                    $input = $this->paymentHelper->add_type_info($input, $order);

                    switch (get_locale()) {
                    case 'zh_HK':
                    case 'zh_TW':
                        $input['Language'] = 'zh-TW';
                        break;
                    case 'ko_KR':
                        $input['Language'] = 'ko';
                        break;
                    case 'ja':
                        $input['Language'] = 'ja';
                        break;
                    case 'zh_CN':
                        $input['Language'] = 'zh-CN';
                        break;
                    case 'en_US':
                    case 'en_AU':
                    case 'en_CA':
                    case 'en_GB':
                    default:
                        $input['Language'] = 'en';
                        break;
                    }

                    syspay_log('付款頁 ' . print_r($input, true), 'A00004', $order_id);

                    $generateForm = $autoSubmitFormService->generate($input, $api_payment_info['action']);

                    echo $generateForm;

                } catch (RtnException $e) {
                    syspay_log('[Exception] (' . $e->getCode() . ')' . $e->getMessage(), 'A90004', $order_id);
                    echo wp_kses_post('(' . $e->getCode() . ')' . $e->getMessage()) . PHP_EOL;
                }

                WC()->cart->empty_cart();
                WC()->session->set('store_api_draft_order', 0);
        }
    }

   

    // 感謝頁面
    public function thankyou_page($order_id) {
        if (empty($order_id)) {
            return;
        }

        if (!$order = wc_get_order($order_id)) {
            return;
        }

        switch ($order->get_payment_method()) {
        case 'Woosyspay_Gateway_Atm':
            $template_file = 'payment/atm.php';
            break;

        
        }

        if (isset($template_file)) {
            syspay_log('Thankyou page', 'A00020', $order_id);

            $args = array(
                'order' => $order,
            );

            wc_get_template($template_file, $args, '', WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/templates/');
        }
    }
}
