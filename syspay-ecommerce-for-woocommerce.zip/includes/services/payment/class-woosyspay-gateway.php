<?php

class Woosyspay_Gateway {

    public function __construct() {

        $this->load_api();

        add_filter('woocommerce_payment_gateways', array($this, 'add_method'));
        add_action('woocommerce_loaded', array($this, 'load_payment_gateway'));
        add_action( 'woocommerce_blocks_loaded', array($this, 'load_payment_gateway_block'));

        // Email發送內容
        if (get_option('woosyspay_enabled_payment_disp_email') == 'yes') {
            add_action('woocommerce_email_after_order_table', array($this, 'add_email_payment_info'), 10, 4);
        }
    }

    /**
     * 載入回傳相關設定
     * @var array
     */
    private function load_api() {
        require_once WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/services/payment/syspay-gateway-response.php';
    }

    /**
     * 載入付款方式
     * @var array
     */
    public function load_payment_gateway() {

        include WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/services/payment/syspay-gateway-base.php';
        include WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/services/payment/syspay-gateway-credit.php';
        include WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/services/payment/syspay-gateway-credit-installment.php';
        include WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/services/payment/syspay-gateway-atm.php';
    }

    public function add_method($methods) {
        $methods[] = 'Woosyspay_Gateway_Credit';
        $methods[] = 'Woosyspay_Gateway_Credit_Installment';
        $methods[] = 'Woosyspay_Gateway_Atm';

        return $methods;
    }

    /**
     * 宣告付款方式支援 Woocommerce Block
     */
    public function load_payment_gateway_block() {
        if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
            require_once WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/services/payment/class-woosyspay-gateway-block.php';
        
            add_action(
                'woocommerce_blocks_payment_method_type_registration',
                function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
                    $payment_method_registry->register(new Woosyspay_Gateway_Block('Woosyspay_Gateway_Credit'));
                    $payment_method_registry->register(new Woosyspay_Gateway_Block('Woosyspay_Gateway_Credit_Installment'));
                    $payment_method_registry->register(new Woosyspay_Gateway_Block('Woosyspay_Gateway_Atm'));
                    
                }
            );
        }
    }

    // EMAIL 顯示付款資訊樣板
    public function add_email_payment_info($order, $sent_to_admin, $plain_text, $email) {
        
        if ($email->id == 'customer_on_hold_order') {

            switch ($order->get_payment_method()) {
            case 'Woosyspay_Gateway_Atm':
                $template_file = 'payment_email/atm.php';
                break;
            }
            if (isset($template_file)) {

                $args = array(
                    'order'         => $order,
                    'sent_to_admin' => $sent_to_admin,
                    'plain_text'    => $plain_text,
                    'email'         => $email,
                );

                wc_get_template($template_file, $args, '', WOOSYSPAY_PLUGIN_INCLUDE_DIR . '/templates/');
            }
        }
    }
}
