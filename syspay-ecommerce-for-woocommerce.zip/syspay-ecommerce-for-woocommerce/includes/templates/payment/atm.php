<?php

defined('ABSPATH') || exit;

// var_dump($order->get_payment_method() );
// return ;


if ($order->get_payment_method() != 'Woosyspay_Gateway_Atm') {
    return;
}

?>
<section class="woocommerce-order-details">
    <h2 class="woocommerce-order-details__title">
        <?php echo( __('Payment info', 'syspay-ecommerce-for-woocommerce')); ?>
    </h2>
    <table class="woocommerce-table woocommerce-table--payment-details payment_details">
        <tbody>
            <tr>
                <td>
                    <?php echo( __('Bank Name', 'syspay-ecommerce-for-woocommerce')); ?>
                </td>
                <td><?php echo wp_kses_post($order->get_meta('_syspay_atm_BankName'));  ?>
                </td>
            </tr>
            <tr>
                <td>
                    <?php echo( __('Bank code', 'syspay-ecommerce-for-woocommerce')); ?>
                </td>
                <td><?php echo wp_kses_post($order->get_meta('_syspay_atm_BankCode'));  ?>
                </td>
            </tr>
            <tr>
                <td>
                    <?php echo(  __('ATM Bank account', 'syspay-ecommerce-for-woocommerce')); ?>
                </td>
                <td><?php echo( wordwrap($order->get_meta('_syspay_atm_vAccount'), 4, '<span> </span>', true)); ?>
                </td>
            </tr>
            <tr>
                <td>
                    <?php echo( __('Payment deadline', 'syspay-ecommerce-for-woocommerce')); ?>
                </td>
                <td>
                    <?php $expireDate = wc_string_to_datetime( wp_kses_post($order->get_meta('_syspay_atm_ExpireDate'))); ?>
                    <?php echo($expireDate->date_i18n(wc_date_format())); ?>
                </td>
            </tr>
        </tbody>
    </table>
</section>
