<?php

use Syspay\Sdk\Exceptions\RtnException;
use Syspay\Sdk\Factories\Factory;
use Syspay\Sdk\Response\VerifiedArrayResponse;
use Helpers\Payment\Woosyspay_Payment_Helper;

#[AllowDynamicProoerties]
class Woosyspay_Gateway_Response {
    protected $paymentHelper;

    public function __construct() {
        add_action('woocommerce_api_woosyspay_payment_callback', [$this, 'check_callback']);

        // 載入共用
        $this->paymentHelper  = new Woosyspay_Payment_Helper;
    }

    // payment response
    public function check_callback() {
        $api_info = $this->paymentHelper->get_syspay_payment_api_info();

        try {
            $factory = new Factory([
                'hashKey' => $api_info['hashKey'],
                'hashIv'  => $api_info['hashIv'],
            ]);

            $checkoutResponse = $factory->create(VerifiedArrayResponse::class);
            $info             = $checkoutResponse->get($_POST);

            // 解析訂單編號
            $order_id = $this->paymentHelper->get_order_id_by_merchant_trade_no($info);

            syspay_log('付款結果 ' . print_r($_POST, true), 'A00007', $order_id);

            // 取出訂單資訊
            if ($order = wc_get_order($order_id)) {

                // 取出訂單金額
                $order_total = $order->get_total();

                // 金額比對
                if ($info['TradeAmt'] == $order_total) {

                    // 更新訂單付款結果
                    $this->paymentHelper->update_order_syspay_orders_payment_status($order_id, $info);

                    // 判斷狀態
                    switch ($info['RtnCode']) {

                    // 付款完成
                    case 1:
                        if (isset($info['SimulatePaid']) && $info['SimulatePaid'] == 0) {
                            

                            // 判斷回傳的精誠金融金流特店交易編號是否已付款
                            $is_syspay_paid = $this->paymentHelper->is_syspay_order_paid($order_id, $info['MerchantTradeNo']);

                            if (!$is_syspay_paid) {
                                $order->add_order_note(__('Payment completed', 'syspay-ecommerce-for-woocommerce'));

                                $order->update_meta_data('_syspay_card6no', $info['card6no']);
                                $order->update_meta_data('_syspay_card4no', $info['card4no']);
                                
                                $order->payment_complete();

                                syspay_log('精誠金融訂單付款完成', 'A00009', $order_id);
                                
                            }
                        } else {
                            // 模擬付款 僅執行備註寫入
                            $note = print_r($info, true);
                            $order->add_order_note('模擬付款/回傳參數：' . $note);

                            syspay_log('精誠金融訂單模擬付款', 'A00008', $order_id);
                        }
                        $order->update_meta_data('_syspay_payment_number_of_periods', $info['stage']);
                        $order->save_meta_data();
                        break;

                    // ATM匯款帳號回傳
                    case 2:

                        if (!$order->is_paid()) {

                            
                            //$expireDate = new DateTime($info['ExpireDate'], new DateTimeZone('Asia/Taipei'));

                            $order->update_meta_data('_syspay_atm_BankName', $info['BankName']);
                            $order->update_meta_data('_syspay_atm_BankCode', $info['BankCode']);
                            $order->update_meta_data('_syspay_atm_vAccount', $info['vAccount']);
                            //$order->update_meta_data('_syspay_atm_ExpireDate', $expireDate->format(DATE_ATOM));
                            $order->update_meta_data('_syspay_atm_ExpireDate', $info['ExpireDate']);
                            

                            $order->save_meta_data();

                            $order->update_status('on-hold');

                            syspay_log('精誠金融訂單取號或申請成功', 'A00010', $order_id);
                        }
                        break;

                    

                    // 付款失敗
                    default:

                        if ($order->is_paid()) {

                            $order->add_order_note(__('Payment failed within paid order', 'syspay-ecommerce-for-woocommerce'));
                            $order->save();

                            syspay_log('精誠金融訂單付款失敗', 'A00012', $order_id);
                        } else {

                            $order->update_status('failed');

                            syspay_log('精誠金融訂單付款失敗', 'A00013', $order_id);
                        }

                        break;
                    }

                    echo '1|OK';
                    exit;
                }
            }

        } catch (RtnException $e) {
            syspay_log('[Exception] (' . $e->getCode() . ')' . $e->getMessage(), 'A90007', $order_id ?: $_POST['MerchantTradeNo']);
            echo wp_kses_post('(' . $e->getCode() . ')' . $e->getMessage()) . PHP_EOL;
        }
    }

    
}

return new Woosyspay_Gateway_Response();
