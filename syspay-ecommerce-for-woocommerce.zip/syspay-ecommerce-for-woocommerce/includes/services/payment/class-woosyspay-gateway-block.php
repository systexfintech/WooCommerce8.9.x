<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

class Woosyspay_Gateway_Block extends AbstractPaymentMethodType {

    protected $gateway;
    protected $name;

    public function __construct(string $name) {
        $this->name = $name;
        $this->settings = get_option('woocommerce_' . $this->name . '_settings', false);
    }

    public function initialize() {
        $this->gateway = new $this->name();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {
        $js_url = '';
        switch ($this->name) {
            case 'Woosyspay_Gateway_Credit':
			    $js_url = WOOSYSPAY_PLUGIN_URL . 'public/js/blocks/credit-checkout.js';
                break;
            case 'Woosyspay_Gateway_Credit_Installment':
                $js_url = WOOSYSPAY_PLUGIN_URL . 'public/js/blocks/credit-installment-checkout.js';
                break;
            case 'Woosyspay_Gateway_Atm':
                $js_url = WOOSYSPAY_PLUGIN_URL . 'public/js/blocks/atm-checkout.js';
                break;
            
        }

        wp_register_script(
            $this->name . '-blocks-integration',
            $js_url,
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );

        if(function_exists('wp_set_script_translations')) {
            wp_set_script_translations($this->name . '-blocks-integration');
        }
        return [$this->name . '-blocks-integration'];
    }

    public function get_payment_method_data() {
        return [
            'title' => $this->gateway->title,
            'id' => $this->gateway->id,
        ];
    }
}
