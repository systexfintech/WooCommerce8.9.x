<?php
return [
    [
        'title' => __('Enable SYSPay method', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_main_options',
        'type' => 'title',
    ],
    [
        'name'     => __('Enable SYSPay gateway method', 'syspay-ecommerce-for-woocommerce'),
        'type'     => 'checkbox',
        'desc'     => __('Enable SYSPay gateway method', 'syspay-ecommerce-for-woocommerce'),
        'id'       => 'woosyspay_enabled_payment',
        'default'  => 'no',
        'desc_tip' => true,
    ],
    [
        'title' => __('API settings', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_payment_options',
        'type' => 'title',
    ],
    [
        'name'     => __( 'SYSPay sandbox', 'syspay-ecommerce-for-woocommerce' ),
        'type'     => 'checkbox',
        'desc'     => __( 'SYSPay sandbox', 'syspay-ecommerce-for-woocommerce' ),
        'id'       => 'woosyspay_enabled_payment_stage',
        'default'  => 'no',
        'desc_tip' => true,  
    ],
    [
        'name'     => __('Enable SYSPay debug log', 'syspay-ecommerce-for-woocommerce'),
        'type'     => 'checkbox',
        'desc'     => __('Enable SYSPay debug log', 'syspay-ecommerce-for-woocommerce') . '<br>' . __('Due to the large size of the log file, please remember to disable this feature if not in use.', 'syspay-ecommerce-for-woocommerce') . '<br>' . sprintf(__('Log folder : <code>%s</code>', 'syspay-ecommerce-for-woocommerce'), WOOSYSPAY_PLUGIN_LOG_DIR) . '<br>' . __('<input class="button" style="margin-top: 5px;" type="button" value="Clear Log" onclick="woosyspayClearSyspayDebugLog();">', 'syspay-ecommerce-for-woocommerce'),
        'id'       => 'woosyspay_enabled_debug_log',
        'default'  => 'no',
        'desc_tip' => true,
    ],
    [
        'type' => 'sectionend',
    ],
];
