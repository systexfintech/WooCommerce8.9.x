<?php
return [
    [
        'title' => __('Gateway settings', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_payment_options',
        'type' => 'title',
    ],
    [
        'title' => __('Order no prefix', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_payment_order_prefix',
        'type' => 'text',
        'desc' => __('Only a maximum of 5-character letters and numbers are allowed.', 'syspay-ecommerce-for-woocommerce'),
        'desc_tip' => true,
        'custom_attributes' => [
            'pattern' => '^[a-zA-Z0-9]{0,5}$',
        ]
    ],
    [
        'name'     => __( 'Display order item name', 'syspay-ecommerce-for-woocommerce' ),
        'type'     => 'checkbox',
        'desc'     => __( 'Display order item name', 'syspay-ecommerce-for-woocommerce' ),
        'id'       => 'woosyspay_enabled_payment_disp_item_name',
        'default'  => 'no',
        'desc_tip' => true,  
    ],
    [
        'name'     => __( 'Show payment info in email', 'syspay-ecommerce-for-woocommerce' ),
        'type'     => 'checkbox',
        'desc'     => __( 'Enabled payment disp email', 'syspay-ecommerce-for-woocommerce' ),
        'id'       => 'woosyspay_enabled_payment_disp_email',
        'default'  => 'no',
        'desc_tip' => true,  
    ],
    [
        'type' => 'sectionend',
    ],

    [
        'title' => __('API settings', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_payment_options',
        'type' => 'title',
    ],
    // [
    //     'name'     => __( 'SYSPay sandbox', 'syspay-ecommerce-for-woocommerce' ),
    //     'type'     => 'checkbox',
    //     'desc'     => __( 'SYSPay sandbox', 'syspay-ecommerce-for-woocommerce' ),
    //     'id'       => 'woosyspay_enabled_payment_stage',
    //     'default'  => 'no',
    //     'desc_tip' => true,  
    // ],
    [
        'title' => __('MerchantID', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_payment_mid',
        'type' => 'text',
        'desc_tip' => true
    ],
    [
        'title' => __('HashKey', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_payment_hashkey',
        'type' => 'text',
        'desc_tip' => true
    ],
    [
        'title' => __('HashIV', 'syspay-ecommerce-for-woocommerce'),
        'id' => 'woosyspay_payment_hashiv',
        'type' => 'text',
        'desc_tip' => true
    ],
    [
        'type' => 'sectionend',
    ],
];
