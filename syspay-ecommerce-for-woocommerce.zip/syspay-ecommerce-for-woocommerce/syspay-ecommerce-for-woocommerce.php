<?php
/**
 * @copyright Copyright (c) 2024 SystexFintech Service Co., Ltd. (https://www.systexfintech.com)
 * @version 1.1.2407100
 *
 * Plugin Name: SYSPay Ecommerce for WooCommerce
 * Plugin URI: https://www.systexfintech.com
 * Description: Syspay Plug for WooCommerce
 * Version: 1.0
 * Author: SYSPay SystexFintech Service Co., Ltd.
 * Author URI: https://www.systexfintech.com
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /languages
 * WC requires at least: 8
 * WC tested up to: 8.9.3
 */

// 相關檢查
defined('ABSPATH') or exit;

// 相關常數定義
define('WOOSYSPAY_VERSION', '1.0');
define('WOOSYSPAY_REQUIREMENT_WOOCOMMERCE_VERSION', '8.9.3');
define('WOOSYSPAY_PLUGIN_NAME', 'syspay-ecommerce-for-woocommerce');
define('WOOSYSPAY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WOOSYSPAY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WOOSYSPAY_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('WOOSYSPAY_PLUGIN_INCLUDE_DIR', WOOSYSPAY_PLUGIN_DIR . 'includes');
define('WOOSYSPAY_PLUGIN_LOG_DIR', WOOSYSPAY_PLUGIN_DIR . 'logs');

//
require_once WOOSYSPAY_PLUGIN_DIR . '/vendor/autoload.php';

// 相關載入程序
require plugin_dir_path(__FILE__) . 'admin/settings/class-woosyspay-setting.php';
require plugin_dir_path(__FILE__) . 'admin/order/class-woosyspay-order.php';


// 載入金流共用 helper
require plugin_dir_path(__FILE__) . 'includes/services/helpers/payment/syspay-payment-helper.php';


// 資料庫處理程序
// register_activation_hook: 手動啟用外掛時觸發
// upgrader_process_complete: 更新外掛時觸發
// plugins_loaded: 用於版本檢查，以防 upgrader_process_complete 抓到舊版本程式的問題
require_once WOOSYSPAY_PLUGIN_DIR . 'includes/services/database/syspay-db-process.php';
register_activation_hook(__FILE__, array('Woosyspay_Db_Process', 'syspay_db_process'));
add_action('upgrader_process_complete', array('Woosyspay_Db_Process', 'syspay_db_process'));
add_action('woocommerce_loaded', array('Woosyspay_Db_Process', 'syspay_db_process'));


// Woocommerce版本判斷
add_action('admin_notices',
    function () {
        if (!defined('WC_VERSION') || version_compare(WC_VERSION, WOOSYSPAY_REQUIREMENT_WOOCOMMERCE_VERSION, '<')) {
            $notice = sprintf(
                __('<strong>%1$s</strong> is inactive. It require WooCommerce version %2$s or newer.', 'syspay-ecommerce-for-woocommerce'),
                __('SYSPay Ecommerce for WooCommerce', 'syspay-ecommerce-for-woocommerce'),
                WOOSYSPAY_REQUIREMENT_WOOCOMMERCE_VERSION
            );
            printf('<div class="error"><p>%s</p></div>', $notice);
        }
    }
);

add_action('before_woocommerce_init',
    function () {
        if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
            // 高效能宣告
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            // Woocmmerce Payment Block
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        }
    }
);




// 載入 log 功能
require WOOSYSPAY_PLUGIN_DIR . 'includes/services/helpers/logger/syspay-logger.php';
function syspay_log($content, $code = '', $order_id = '') {
    $logger = new Helpers\Logger\Woosyspay_Logger;
    return $logger->log($content, $code, $order_id);
}
function syspay_log_replace_symbol($type, $data) {
    $logger = new Helpers\Logger\Woosyspay_Logger;
    return $logger->replace_symbol($type, $data);
}

$plugin_main  = new Woosyspay_Setting();
$plugin_order = new Woosyspay_Order();

if ('yes' === get_option('woosyspay_enabled_payment', 'no')) {
    require plugin_dir_path(__FILE__) . 'includes/services/payment/class-woosyspay-gateway.php';
    $plugin_payment = new Woosyspay_Gateway();
}
