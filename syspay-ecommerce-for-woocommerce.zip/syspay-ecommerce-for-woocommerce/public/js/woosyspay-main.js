
// (金流)標示精誠金融重複付款訂單已處理
function woosyspayDuplicatePaymentComplete(order_id, merchant_trade_no_list) {

    query = {
        action: 'duplicate_payment_complete',
        order_id: order_id,
        merchant_trade_no_list: merchant_trade_no_list
    };

    jQuery.blockUI({ message: null });

    jQuery.post(ajaxurl, query, function(response) {

        var response_info = jQuery.parseJSON(response);
        window.location.reload();

        jQuery.unblockUI()
    });
}

// (工具)清理 Log
function woosyspayClearSyspayDebugLog() {

    query = {
        action: 'clear_syspay_debug_log'
    };

    jQuery.post(ajaxurl, query, function(response) {
        //
    })
    .success (function() {
        alert('Log 已清空!');
    })
    .error (function () {
        console.log('清理Log失敗')
    });
}