const Woosyspay_credit_settings = window.wc.wcSettings.getSetting('Woosyspay_Gateway_Credit_data', {});

const Woosyspay_Credit_Content = () => {
    return window.wp.htmlEntities.decodeEntities(Woosyspay_credit_settings.description || '');
};
const Woosyspay_Credit_Block_Gateway = {
    name: 'Woosyspay_Gateway_Credit',
    label: window.wp.htmlEntities.decodeEntities(Woosyspay_credit_settings.title || ''),
    content: Object(window.wp.element.createElement)(Woosyspay_Credit_Content, null),
    edit: Object(window.wp.element.createElement)(Woosyspay_Credit_Content, null),
    canMakePayment: () => true,
    ariaLabel: window.wp.htmlEntities.decodeEntities(Woosyspay_credit_settings.title || ''),
    supports: {
        features: Woosyspay_credit_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod(Woosyspay_Credit_Block_Gateway);