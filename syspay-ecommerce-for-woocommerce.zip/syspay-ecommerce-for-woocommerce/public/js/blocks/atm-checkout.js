const Woosyspay_atm_settings = window.wc.wcSettings.getSetting('Woosyspay_Gateway_Atm_data', {});

const Woosyspay_Atm_Content = () => {
    return window.wp.htmlEntities.decodeEntities(Woosyspay_atm_settings.description || '');
};
const Woosyspay_Atm_Block_Gateway = {
    name: 'Woosyspay_Gateway_Atm',
    label: window.wp.htmlEntities.decodeEntities(Woosyspay_atm_settings.title || ''),
    content: Object(window.wp.element.createElement)(Woosyspay_Atm_Content, null),
    edit: Object(window.wp.element.createElement)(Woosyspay_Atm_Content, null),
    canMakePayment: () => true,
    ariaLabel: window.wp.htmlEntities.decodeEntities(Woosyspay_atm_settings.title || ''),
    supports: {
        features: Woosyspay_atm_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod(Woosyspay_Atm_Block_Gateway);