=== syspay-ecommerce-for-woocommerce ===
Contributors: syspaytechsupport
Tags: ecommerce, e-commerce, store, sales, sell, shop, cart, checkout, payment, syspay
Requires at least: 6
Tested up to: 6.7.1
Requires PHP: 8.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Frequently Asked Questions ==
= 系統需求 =

- PHP version 8.2
- MySQL version 5.7 or greater

= 其它問題 =
請來信詢問精誠金融技術服務信箱: syspaysupport@systexfintech.com

== Changelog ==

v1.0
初版 WordPress Version 6.7.1
初版 WooCommerce Version 8.9.3

== Upgrade Notice ==

Upgrade Notice 請使用https://github.com/SYSPay/Woocommerce_SYSPAY

== Screenshots ==



精誠金融科技 WooCommerce 模組
===============
<p align="center">
    <img alt="Last Release" src="https://img.shields.io/github/release/SYSPay/Woocommerce_SYSPAY.svg">
</p>

== Description ==

* 精誠金融科技外掛套件，提供合作特店以及個人賣家使用開放原始碼商店系統時，無須自行處理複雜的檢核，直接透過安裝設定外掛套件，便可快速介接精誠金融科技系統，進行金流操作。
* 金流支援付款方式：信用卡一次付清、信用卡分期付款、ATM銀行轉帳。

目錄
-----------------
* [支援版本](#支援版本)
* [安裝](#安裝)
* [設定與功能項目](#設定與功能項目)
    1. [參數設定](#參數設定)
    2. [後台訂單](#後台訂單)
* [技術支援](#技術支援)
* [附錄](#附錄)
* [版權宣告](#版權宣告)



支援版本
-----------------
| Wordpress  | WooCommerce | PHP |
| :---------: | :----------: | :----------: |
| 6.7.1 | 8.9.3 | 8.2 |


安裝
-----------------
#### 解壓縮套件檔
將下載的套件檔解壓縮，解壓縮完成後中會有一份壓縮檔「syspay-ecommerce-for-woocommerce.zip」，用來上傳的外掛模組。

#### 上傳模組
`購物車後台` -> `外掛(Plugins)` -> `安裝外掛(Add New)` -> `上傳外掛(Upload Plugin)` -> `選擇檔案(選擇壓縮檔「syspay-ecommerce-for-woocommerce.zip」)`-> `立即安裝(Install Now)`。

#### 啟用模組
安裝完成後，畫面會顯示是否安裝成功，若安裝成功會出現`啟用外掛(Active Plugin)`的按鈕，按下`啟用外掛(Active Plugin)`後即可開始使用精誠金融模組。

設定與功能項目
-----------------

#### 參數設定
##### 設定路徑
- `購物車後台` -> `WooCommerce` -> `設定(Settings)`，點選精誠金融科技分頁。

##### 主要設定
- 您可在此勾選需要啟用的精誠金融服務。
##### 金流設定
- 您可在此設定金流相關參數。
    - 訂單編號前綴
    - 精誠金融訂單顯示商品名稱
    - 啟用測試模式
    - 商店代號(Merchant ID)
    - 金鑰(Hash Key)
    - 向量(Hash IV)


##### 注意事項
- 

#### 後台訂單


技術支援
-----------------
精誠金融技術服務工程師信箱: syspaysupport@systexfintech.com


附錄
-----------------

#### 測試串接參數

|  | 特店編號(MerchantID) | HashKey | HashIV |
| -------- | -------- | -------- | -------- |
| 金流     | 請直接在測試環境申請或跟金流顧問索取     |      |      |


