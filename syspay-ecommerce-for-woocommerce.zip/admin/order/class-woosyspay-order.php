<?php

use Syspay\Sdk\Exceptions\RtnException;
use Syspay\Sdk\Factories\Factory;
use Helpers\Logger\Woosyspay_Logger;
use Helpers\Payment\Woosyspay_Payment_Helper;

class Woosyspay_Order {
    protected $loggerHelper;
    protected $paymentHelper;

    public function __construct() {
        // 載入共用
        $this->loggerHelper   = new Woosyspay_Logger;
        $this->paymentHelper  = new Woosyspay_Payment_Helper;

        if (is_admin()) {
            add_action('admin_enqueue_scripts', array($this, 'woosyspay_register_scripts'));

            if ('yes' === get_option('woosyspay_enabled_payment', 'yes')) {
                add_action('woocommerce_admin_billing_fields', array($this, 'custom_order_meta'), 10, 1);
                add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'add_address_meta'), 10, 1);

                add_action('woocommerce_admin_order_data_after_order_details', array($this, 'add_payment_info'), 10, 1);
                add_action('woocommerce_admin_order_data_after_order_details', array($this, 'check_order_status_cancel'));
                add_action('woocommerce_admin_order_data_after_order_details', array($this, 'check_order_is_duplicate_payment'));

                add_action('manage_shop_order_posts_custom_column', array($this, 'custom_orders_list_column_content'), 20, 2);

                add_action('wp_ajax_duplicate_payment_complete', array($this, 'ajax_duplicate_payment_complete'));
            }

            

            // 清理 Log
            add_action('wp_ajax_clear_syspay_debug_log', array($this, 'ajax_clear_syspay_debug_log'));
        }
    }

    /**
     * 訂單頁面新增完整地址
     */
    public function custom_order_meta($fields) {
        $fields['full-address'] = array(
            'label'         => __('Full address', 'syspay-ecommerce-for-woocommerce'),
            'show'          => true,
            'wrapper_class' => 'form-field-wide full-address',
        );

        return $fields;
    }

    /**
     * 訂單頁面姓名欄位格式調整
     */
    public function add_address_meta($order) {
        echo '<style>.order_data_column:nth-child(2) .address p:first-child {display: none;}</style>';

        $shipping_method_id = $order->get_items('shipping');
        if (!empty($shipping_method_id)) {
            $shipping_method_id = reset($shipping_method_id);
            $shipping_method_id = $shipping_method_id->get_method_id();
        }
        
        echo '<style>.logistic_button_display {display: inline-block;}</style>';

        echo wp_kses_post('<p><strong>帳單姓名:<br/></strong>' . $order->get_billing_last_name() . ' ' . $order->get_billing_first_name() . '</p>');
    }

    /**
     * 訂單金流資訊回傳
     */
    public function add_payment_info($order) {
        $payment_method = $order->get_payment_method();

        echo '<p>&nbsp;</p>';
        echo '<h3>' . __('Gateway info', 'syspay-ecommerce-for-woocommerce') . '</h3>';

        echo wp_kses_post('<p><strong>' . __('Payment Type', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_payment_method_title() . '</p>');

        switch ($payment_method) {
            case 'Woosyspay_Gateway_Credit':
                echo wp_kses_post('<p><strong>' . __('Card No 6', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_meta('_syspay_card6no', true) . '</p>');
                echo wp_kses_post('<p><strong>' . __('Card No 4', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_meta('_syspay_card4no', true) . '</p>');
                break;
            case 'Woosyspay_Gateway_Credit_Installment':
                echo wp_kses_post('<p><strong>' . __('Number of periods', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_meta('_syspay_payment_number_of_periods', true) . '</p>');
                break;
            case 'Woosyspay_Gateway_Atm':
                echo wp_kses_post('<p><strong>' . __('Bank Name', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_meta('_syspay_atm_BankName', true) . '</p>');
                echo wp_kses_post('<p><strong>' . __('Bank code', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_meta('_syspay_atm_BankCode', true) . '</p>');
                echo wp_kses_post('<p><strong>' . __('ATM No', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_meta('_syspay_atm_vAccount', true) . '</p>');
                echo wp_kses_post('<p><strong>' . __('Payment deadline', 'syspay-ecommerce-for-woocommerce') . ':&nbsp;</strong>' . $order->get_meta('_syspay_atm_ExpireDate', true) . '</p>');
                break;
            default:
                break;
        }
    }

    /**
     * 無效訂單狀態更新
     *
     * @return void
     */
    public function check_order_status_cancel($order) {

        $query_trade_tag = $order->get_meta('_woosyspay_query_trade_tag', true);

        if ($query_trade_tag == 0) {
            // 判斷訂單狀態
            $order_status = $order->get_status();
            if (
                $order_status == 'on-hold' ||
                $order_status == 'pending'
            ) {

                // 判斷金流方式
                $payment_method = $order->get_payment_method();

                if (
                    $payment_method == 'Woosyspay_Gateway_Credit' ||
                    $payment_method == 'Woosyspay_Gateway_Credit_Installment' ||
                    $payment_method == 'Woosyspay_Gateway_Atm'
                ) {
                    // 判斷是否超過指定時間或自訂的保留時間

                    // 計算訂單建立時間是否超過指定時間
                    if (
                        $payment_method == 'Woosyspay_Gateway_Credit' ||
                        $payment_method == 'Woosyspay_Gateway_Credit_Installment'
                    ) {
                        $offset = 60; // 信用卡
                    } else {
                        $offset = 4320; // ATM 3天
                    }

                    // 若使用者自訂的保留時間 > 精誠金融時間，則使用使用者設定的時間
                    $hold_stock_minutes = empty(get_option('woocommerce_hold_stock_minutes')) ? 0 : get_option('woocommerce_hold_stock_minutes'); // 取得保留庫存時間

                    if ($hold_stock_minutes > $offset) {
                        $offset = $hold_stock_minutes;
                    }

                    $date_created = $order->get_date_created()->getTimestamp(); // 訂單建立時間
                    $dateCompare  = strtotime('- ' . $offset . ' minute');
                    
                    // 反查精誠金融訂單記錄API
                    if ($date_created <= $dateCompare) {
                        
                        $api_payment_query_trade_info = $this->paymentHelper->get_syspay_payment_api_info('QueryTradeInfo');
                        $merchant_trade_no            = $order->get_meta('_woosyspay_payment_merchant_trade_no', true);
                        
                        try {

                            $factory = new Factory([
                                'hashKey' => $api_payment_query_trade_info['hashKey'],
                                'hashIv'  => $api_payment_query_trade_info['hashIv'],
                            ]);

                            $postService = $factory->create('PostWithCmvVerifiedEncodedStrResponseService');

                            $input = [
                                'MerchantID'      => $api_payment_query_trade_info['merchant_id'],
                                'MerchantTradeNo' => $merchant_trade_no,
                                'TimeStamp'       => time(),
                            ];
                            
                            $response = $postService->post($input, $api_payment_query_trade_info['action']);
                            
                            foreach( $response as $k => $v ) {
                                $response = json_decode( $k, true );
                            }
                            // 逾期交易失敗
                            if (isset($response['TradeStatus']) && $response['TradeStatus'] == 0) {

                                // 更新訂單狀態/備註
                                $order->add_order_note('逾期訂單自動取消');

                                $order->update_status('cancelled');
                                $order->update_meta_data('_woosyspay_query_trade_tag', 1);

                                $order->save();
                            }
                        } catch (RtnException $e) {
                            
                            echo '(' . $e->getCode() . ')' . $e->getMessage() . PHP_EOL;
                        }
                    }
                }
            }
        }
    }

    

    /**
     * 註冊JS
     */
    public function woosyspay_register_scripts() {
        wp_register_script(
            'woosyspay_main',
            WOOSYSPAY_PLUGIN_URL . 'public/js/woosyspay-main.js',
            array(),
            '1.0.2',
            true
        );

        // 載入js
        wp_enqueue_script('woosyspay_main');
    }

    

    /**
     * 調整後台訂單列表頁欄位內容
     */
    public function custom_orders_list_column_content($column, $post_id) {
        switch ($column) {
        case 'order_number':
            if ($order = wc_get_order($post_id)) {
                // 檢查訂單是否可能有精誠金融訂單重複付款情形
                $is_duplicate_payment = $this->paymentHelper->check_order_is_duplicate_payment($order);
                if ($is_duplicate_payment['code'] === 1) {
                    // 顯示 Waring 小圖示
                    echo wp_kses_post('&nbsp;<span class="dashicons dashicons-warning" style="color: red;"></span>');
                }
            }
            break;
        }
    }

    /**
     * 檢查訂單是否重複付款
     */
    public function check_order_is_duplicate_payment($order) {
        $is_duplicate_payment = $this->paymentHelper->check_order_is_duplicate_payment($order);

        // 顯示提示訊息
        if ($is_duplicate_payment['code'] === 1) {
            echo wp_kses_post('<div><p style="color: red;"><span class="dashicons dashicons-warning"></span><strong>' . __('Please confirm the order. The system has detected that there may be duplicate payments for orders. (The order has multiple syspay payment orders or cash on delivery has been selected.)', 'syspay-ecommerce-for-woocommerce') . '</strong></p>');
            echo wp_kses_post('<p style="color: red;"><strong>' . __('Abnormal syspay merchant trade no', 'syspay-ecommerce-for-woocommerce') . ':</strong></p>');

            // 移除空值
            $merchant_trade_no_list = array_filter($is_duplicate_payment['merchant_trade_no'], function ($value, $key) {
                return !is_null($value) && $value !== '';
            }, ARRAY_FILTER_USE_BOTH);

            foreach ($merchant_trade_no_list as $merchant_trade_no) {
                echo wp_kses_post('<p style="color: red;">- ' . $merchant_trade_no . '</p>');
            }

            echo '<input class=\'button\' type=\'button\' onclick=\'woosyspayDuplicatePaymentComplete(' . $order->get_id() . ', ' . json_encode($merchant_trade_no_list) . ');\' value=\'標示已處理\' /></div>';
        }
    }

    /**
     * 精誠金融訂單重複付款提示標示為已處理
     */
    public function ajax_duplicate_payment_complete() {
        if ($order = wc_get_order($_POST['order_id'])) {
            $result = $this->paymentHelper->update_order_syspay_orders_payment_status_complete($_POST['order_id']);

            if (isset($result)) {
                // 組合精誠金融金流特店交易編號
                $merchant_trade_no_list = '';
                foreach ($_POST['merchant_trade_no_list'] as $merchant_trade_no) {
                    $merchant_trade_no_list .= PHP_EOL . $merchant_trade_no;
                }

                $order->add_order_note(sprintf(__('Duplicate payments for syspay orders are marked as processed.%s', 'syspay-ecommerce-for-woocommerce'), $merchant_trade_no_list));
            }
        }
    }

    /**
     * 清理 Log
     */
    public function ajax_clear_syspay_debug_log() {

        $this->loggerHelper->clear_log();

        wp_die();
    }
}